package com.example.jobbank;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class edit_vacancy extends AppCompatActivity {

    EditText description, qualification, department, yrsOfEx, ageLimit, JobType, closingDate;
    DatabaseReference dbRef;
    pubVacancy std;
    Button savePreview;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_vacancy);

        description=findViewById(R.id.multilineDescription1);
        qualification=findViewById(R.id.QualificationEditText1);
        department=findViewById(R.id.departmentEdit1);
        yrsOfEx=findViewById(R.id.yearsOfExEdit1);
        ageLimit=findViewById(R.id.ageLimit1);
        JobType=findViewById(R.id.jobTypeEdit1);
        closingDate=findViewById(R.id.editClosingDate1);

        savePreview=findViewById(R.id.savebtn);

        savePreview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                dbRef = FirebaseDatabase.getInstance().getReference().child("Publish_Vacancy");

                /*try {
                    if(TextUtils.isEmpty(description.getText().toString()))
                        Toast.makeText(getApplicationContext(),"Error in Description",Toast.LENGTH_LONG).show();
                    else if(TextUtils.isEmpty(qualification.getText().toString()))
                        Toast.makeText(getApplicationContext(),"Error in qualification",Toast.LENGTH_LONG).show();
                    else if(TextUtils.isEmpty(department.getText().toString()))
                        Toast.makeText(getApplicationContext(),"Error in Department",Toast.LENGTH_LONG).show();
                    else if(TextUtils.isEmpty(yrsOfEx.getText().toString()))
                        Toast.makeText(getApplicationContext(),"Error in Years of Experience",Toast.LENGTH_LONG).show();
                    else if(TextUtils.isEmpty(ageLimit.getText().toString()))
                        Toast.makeText(getApplicationContext(),"Error in Age Limit",Toast.LENGTH_LONG).show();
                    else if(TextUtils.isEmpty(JobType.getText().toString()))
                        Toast.makeText(getApplicationContext(),"Error in Job Type",Toast.LENGTH_LONG).show();
                    else if(TextUtils.isEmpty(closingDate.getText().toString()))
                        Toast.makeText(getApplicationContext(),"Error in Closing Date",Toast.LENGTH_LONG).show();


                    else
                    {
                        std.setDescription(description.getText().toString().trim());
                        std.setQualification(qualification.getText().toString().trim());
                        std.setDepartment(department.getText().toString().trim()); //Trim is Remove the Spaces in text fields
                        std.setYrsOfExp(yrsOfEx.getText().toString().trim());
                        std.setAgeLimit(ageLimit.getText().toString().trim());
                        std.setJobType(JobType.getText().toString().trim()); //Trim is Remove the Spaces in text fields
                        std.setClosingDate(closingDate.getText().toString().trim());
                        dbRef.child(jobTitle.getText().toString().trim()).setValue(std);
                        Toast.makeText(getApplicationContext(),"Successfully Inserted",Toast.LENGTH_SHORT).show();
                        //clearBox();
                    }*/
               /* }
                catch (NumberFormatException ex){
                    Toast.makeText(getApplicationContext(),"Error in Saving",Toast.LENGTH_SHORT).show();
                }*/


               getUserData();

            }

            //getting user data
            public void getUserData(){

                //globally assigning values
                //String descrip,qualifi,dep,yrs,age,jobt,closingD;

                String descrip = description.getText().toString();
                String qualifi = qualification.getText().toString();
                String dep = department.getText().toString();
                String yrs = yrsOfEx.getText().toString();
                String age = ageLimit.getText().toString();
                String jobt = JobType.getText().toString();
                String closingD = closingDate.getText().toString();

                //DatabaseReference rootref = FirebaseDatabase.getInstance().getReference().child("Des")
            }
        });
    }
}